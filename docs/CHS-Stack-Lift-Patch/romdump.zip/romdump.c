#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "dis_nut.h"

typedef uint16_t rom_word_t;


void trim_trailing_whitespace (char *s)
{
  int i;
  char c;

  i = strlen (s);
  while (--i >= 0)
    {
      c = s [i];
      if ((c == '\n') || (c == '\r') || (c == ' ') || (c == '\t'))
	s [i] = '\0';
      else
	break;
    }
}


static bool parse_hex (char *hex, int digits, int *val)
{
  *val = 0;

  while (digits--)
    {
      char c = *(hex++);
      (*val) <<= 4;
      if ((c >= '0') && (c <= '9'))
	(*val) += (c - '0');
      else if ((c >= 'A') && (c <= 'F'))
	(*val) += (10 + (c - 'A'));
      else if ((c >= 'a') && (c <= 'f'))
	(*val) += (10 + (c - 'a'));
      else
	return (false);
    }
  return (true);
}


static bool nut_parse_object_line (char *buf, int *bank, int *addr,
				   rom_word_t *opcode)
{
  int b = 0;
  int a;
  int o;

  if (buf [0] == '#')  /* comment? */
    return (false);

  if (strlen (buf) != 8)
    return (false);

  if (buf [4] != ':')
    {
      fprintf (stderr, "invalid object file format\n");
      return (false);
    }

  if (! parse_hex (& buf [0], 4, & a))
    {
      fprintf (stderr, "invalid address %o\n", a);
      return (false);
    }

  if (! parse_hex (& buf [5], 3, & o))
    {
      fprintf (stderr, "invalid opcode %o\n", o);
      return (false);
    }

  *bank = b;
  *addr = a;
  *opcode = o;
  return (true);
}


bool read_object_file (char *fn)
{
  FILE *f;
  int bank;
  int addr;  // should change to addr_t, but will have to change
             // the parse function profiles to match.
  rom_word_t opcode;
  int op1, op2;
  int addr1, addr2;
  op2 = addr2 = 0;
  char buf [80];

  f = fopen (fn, "rb");
  if (! f)
    {
      fprintf (stderr, "error opening object file\n");
      return (false);
    }

  while (fgets (buf, sizeof (buf), f))
    {
      trim_trailing_whitespace (buf);
      if (! buf [0])
	    continue;
      if (nut_parse_object_line (buf, & bank, & addr, & opcode))
	    {
          op1 = op2;
          op2 = opcode;
          addr1 = addr2;
          addr2 = addr;
	      if (! nut_disassemble_inst (addr1, op1, op2, buf, sizeof (buf)))
            {
              fprintf (stderr, "can't disassemble instruction at bank %d address %o\n", bank, addr);
              return (false);
            }
          printf (" %s\n", buf);
	    }
    }

  return (true);
}


int main (int argc, char *argv[])
{
  return read_object_file (argv [1]) ? 0 : 1;
}